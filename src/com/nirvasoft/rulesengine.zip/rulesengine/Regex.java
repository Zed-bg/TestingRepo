// 
// Decompiled by Procyon v0.5.36
// 

package com.nirvasoft.rulesengine;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex
{
    public static final String Numeric = "[-+]?[0-9]+\\.?[0-9]*[^%]?";
    public static final String FilePath = "([a-zA-Z]:)?(.)*([a-zA-Z0-9_]+[.][a-zA-Z0-9_]+)+";
    public static final String ConOperator = "([><!=]{1,2})";
    public static final String CalOperator = "[^ ]+ *([\\+\\-\\*\\/]{1}) *[^ ]+.?";
    public static final String Percent = "[-+]?[0-9]*\\.?[0-9]*[%]";
    public static final String Text = "'(.*)'";
    public static final Pattern getText;
    public static final String ProcessCode = "[a-zA-Z]{2}[0-9]*";
    public static final String Goto = "goto\\((.+)\\) *";
    public static final Pattern getGoto;
    public static final String LineIndex = " *(.+): *(.+)";
    public static final Pattern getLineIndex;
    public static final String FunctionName = " *(.*?)\\(.*";
    public static final Pattern getFunctionName;
    public static final Pattern getInnerSingleQuote;
    public static final Pattern getInnerRoundBracket;
    public static final String VariableName = "[a-zA-Z]+[a-zA-Z0-9]*";
    public static final Pattern getVariableName;
    public static final String ValueAssignment = "([a-zA-Z]+[a-zA-Z0-9]*)[ ]*= *(.+)[ ]*";
    public static final Pattern getValueAssignment;
    public static final String ConStatement = "[ ]*([A-Za-z0-9']*) *([><!=]{1,2}) *([A-Za-z0-9']*)[ ]*";
    public static final Pattern getConStatement;
    public static final String IF = "[ ]*[iI][fF] \\((.+)\\) [tT][hH][eE][nN] +([^ ]+) +[eE][lL][sS][eE] *([^ ;]*)[ ;]*";
    public static final Pattern getIF;
    public static final String RuleSet = "<ruleset>(.*)</ruleset>";
    public static final Pattern getRuleSet;
    
    static {
        getText = Pattern.compile("'(.*)'");
        getGoto = Pattern.compile("goto\\((.+)\\) *");
        getLineIndex = Pattern.compile(" *(.+): *(.+)");
        getFunctionName = Pattern.compile(" *(.*?)\\(.*");
        getInnerSingleQuote = Pattern.compile("'(.*?)'");
        getInnerRoundBracket = Pattern.compile("\\((.*?)\\)");
        getVariableName = Pattern.compile("[a-zA-Z]+[a-zA-Z0-9]*");
        getValueAssignment = Pattern.compile("([a-zA-Z]+[a-zA-Z0-9]*)[ ]*= *(.+)[ ]*");
        getConStatement = Pattern.compile("[ ]*([A-Za-z0-9']*) *([><!=]{1,2}) *([A-Za-z0-9']*)[ ]*");
        getIF = Pattern.compile("[ ]*[iI][fF] \\((.+)\\) [tT][hH][eE][nN] +([^ ]+) +[eE][lL][sS][eE] *([^ ;]*)[ ;]*");
        getRuleSet = Pattern.compile("<ruleset>(.*)</ruleset>");
    }
    
    static String extract(final String s, final Pattern p, final int g) {
        String ret = "";
        final Matcher m = p.matcher(s);
        if (m.find()) {
            ret = m.group(g);
        }
        return ret;
    }
}