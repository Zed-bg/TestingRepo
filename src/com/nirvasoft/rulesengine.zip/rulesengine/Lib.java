// 
// Decompiled by Procyon v0.5.36
// 

package com.nirvasoft.rulesengine;

import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import com.nirvasoft.common.Util;

public class Lib
{
    public static boolean greaterThan(final String... data) {
        boolean ret = false;
        final double v0 = Util.dbl(data[0]);
        for (int i = 1; i < data.length; ++i) {
            ret = (v0 > Util.dbl(data[i]));
        }
        return ret;
    }
    
    public static boolean lessThan(final String... data) {
        boolean ret = false;
        final double v0 = Util.dbl(data[0]);
        for (int i = 1; i < data.length; ++i) {
            ret = (v0 < Util.dbl(data[i]));
        }
        return ret;
    }
    
    public static String minus(final String... data) {
        double ret = Util.dbl(data[0]);
        for (int i = 1; i < data.length; ++i) {
            ret -= Util.dbl(data[i]);
        }
        return new StringBuilder().append(ret).toString();
    }
    
    public static String add(final String... data) {
        if (data[0].matches("'(.*)'")) {
            String ret = Regex.extract(data[0], Regex.getText, 1);
            for (int i = 1; i < data.length; ++i) {
                if (data[i].matches("'(.*)'")) {
                    ret = String.valueOf(ret) + Regex.extract(data[i], Regex.getText, 1);
                }
                else {
                    ret = String.valueOf(ret) + data[i];
                }
            }
            return "'" + ret + "'";
        }
        double ret2 = Util.dbl(data[0]);
        for (int j = 1; j < data.length; ++j) {
            ret2 += Util.dbl(data[j]);
        }
        return new StringBuilder().append(ret2).toString();
    }
    
    public static String multiply(final String... data) {
        double ret = Util.dbl(data[0]);
        for (int i = 1; i < data.length; ++i) {
            ret *= Util.dbl(data[i]);
        }
        return new StringBuilder().append(ret).toString();
    }
    
    public static String div(final String... data) {
        double ret = Util.dbl(data[0]);
        for (int i = 1; i < data.length; ++i) {
            ret /= Util.dbl(data[i]);
        }
        return new StringBuilder().append(ret).toString();
    }
    
    public static String zeroTail(final double d) {
        final String s = new StringBuilder().append(d).toString();
        if (s.endsWith(".0")) {
            return s.replace(".0", "");
        }
        return s;
    }
    
    public static String zeroTail(final String s) {
        if (s.endsWith(".0")) {
            return s.replace(".0", "");
        }
        return s;
    }
    
    public static String print(final ArrayList<String> lines, final String prefix, final String postfix) {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < lines.size(); ++i) {
            if (i > 0) {
                sb.append(postfix);
            }
            sb.append(String.valueOf(prefix) + lines.get(i));
        }
        return sb.toString();
    }
    
    public static String removeQ(final String s) {
        return s.replace("'", "");
    }
    
    public static String addQ(final String s) {
        return "'" + s + "'";
    }
    
    public static ArrayList<String> toARL(final String[] lines) {
        return new ArrayList<String>(Arrays.asList(lines));
    }
    
    public static String print(final String[] lines, final String prefix, final String postfix) {
        return print(toARL(lines), prefix, postfix);
    }
}