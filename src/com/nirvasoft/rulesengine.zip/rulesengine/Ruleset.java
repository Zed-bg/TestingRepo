// 
// Decompiled by Procyon v0.5.36
// 

package com.nirvasoft.rulesengine;

import com.nirvasoft.common.Util;
import com.nirvasoft.common.XML;
import java.util.ArrayList;

public class Ruleset
{
    private static String Path;
    private String RuleID;
    private String RuleText;
    private ArrayList<Dataset> Datasets;
    
    static {
        Ruleset.Path = "rules";
    }
    
    public String getRuleID() {
        return this.RuleID;
    }
    
    public void setRuleID(final String ruleID) {
        this.RuleID = ruleID;
    }
    
    public String getRuleText() {
        return this.RuleText;
    }
    
    public void setRuleText(final String ruleText) {
        this.RuleText = ruleText;
    }
    
    public ArrayList<Dataset> getDatasets() {
        return this.Datasets;
    }
    
    public void setDatasets(final ArrayList<Dataset> datasets) {
        this.Datasets = datasets;
    }
    
    public static String getPath() {
        return Ruleset.Path;
    }
    
    public static void setPath(final String path) {
        Ruleset.Path = path;
    }
    
    public static ArrayList<Ruleset> loadText(final String txt, ArrayList<Ruleset> rulesets) {
        final ArrayList<String> rs = (ArrayList<String>)XML.getMultiple(txt.replaceAll("\r", ""), "ruleset");
        if (rulesets == null) {
            rulesets = new ArrayList<Ruleset>();
        }
        for (int j = 0; j < rs.size(); ++j) {
            final Ruleset ruleset = new Ruleset();
            ruleset.setRuleID(XML.get((String)rs.get(j), "id"));
            ruleset.setRuleText(XML.get((String)rs.get(j), "rule"));
            final ArrayList<String> ds = (ArrayList<String>)XML.getMultiple((String)rs.get(j), "dataset");
            final ArrayList<Dataset> datasets = new ArrayList<Dataset>();
            for (int k = 0; k < ds.size(); ++k) {
                final Dataset dataset = new Dataset();
                dataset.setData(XML.getMultiple((String)ds.get(k), "data"));
                dataset.setResult(XML.getMultiple((String)ds.get(k), "result"));
                datasets.add(dataset);
            }
            ruleset.setDatasets(datasets);
            rulesets.add(ruleset);
        }
        return rulesets;
    }
    
    public static String findInFolder(final String ruleid, final String path) {
        final ArrayList<String> arlRuleFiles = (ArrayList<String>)Util.getFileList(path);
        ArrayList<Ruleset> rulesets = new ArrayList<Ruleset>();
        for (int i = 0; i < arlRuleFiles.size(); ++i) {
            if (arlRuleFiles.get(i).endsWith(".xml")) {
                final String txt = Util.readText((String)arlRuleFiles.get(i));
                rulesets = loadText(txt, rulesets);
            }
        }
        return find(ruleid, rulesets);
    }
    
    public static String loadFolder(final String path) {
        final ArrayList<String> arlRuleFiles = (ArrayList<String>)Util.getFileList(path);
        ArrayList<Ruleset> rulesets = new ArrayList<Ruleset>();
        for (int i = 0; i < arlRuleFiles.size(); ++i) {
            if (arlRuleFiles.get(i).endsWith(".xml")) {
                final String txt = Util.readText((String)arlRuleFiles.get(i));
                rulesets = loadText(txt, rulesets);
            }
        }
        return toString(rulesets);
    }
    
    public static String listFolder(final String path) {
        final ArrayList<String> arlRuleFiles = (ArrayList<String>)Util.getFileList(path);
        return Util.toString((ArrayList)arlRuleFiles);
    }
    
    public static String findInFile(final String ruleid, final String path) {
        final ArrayList<Ruleset> arlRS = loadText(Util.readText(path), null);
        return find(ruleid, arlRS);
    }
    
    public static String find(final String ruleid, final ArrayList<Ruleset> arlRS) {
        String rules = "";
        for (int i = 0; i < arlRS.size(); ++i) {
            if (arlRS.get(i).getRuleID().equalsIgnoreCase(ruleid)) {
                rules = arlRS.get(i).getRuleText();
            }
        }
        return rules;
    }
    
    public static String toString(final ArrayList<Ruleset> rs) {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < rs.size(); ++i) {
            sb.append("<<< " + rs.get(i).getRuleID() + " >>>\n" + rs.get(i).getRuleText() + "\n");
            for (int j = 0; j < rs.get(i).Datasets.size(); ++j) {
                sb.append(String.valueOf(Util.toString(rs.get(i).getDatasets().get(j).getData())) + "\n" + Util.toString(rs.get(i).getDatasets().get(j).getResult()) + "\n");
            }
        }
        return sb.toString();
    }
}