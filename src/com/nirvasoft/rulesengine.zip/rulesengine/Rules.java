// 
// Decompiled by Procyon v0.5.36
// 

package com.nirvasoft.rulesengine;

import com.nirvasoft.common.Util;
import java.util.Arrays;
import java.util.TreeMap;

public class Rules
{
    public static String processID(final String id) {
        return processID(null, id, null, null);
    }
    
    public static String processID(final String id, final TreeMap<String, String> aVariables) {
        return processID(null, id, aVariables, null);
    }
    
    public static String processID(final String[] aInput, final String id, final TreeMap<String, String> aVariables) {
        return processID(aInput, id, aVariables, null);
    }
    
    public static String processID(final String[] aInput, final String id, final TreeMap<String, String> aVariables, final StringBuffer aLog) {
        final String rules = Ruleset.findInFolder(id, Ruleset.getPath());
        return process(aInput, rules, aVariables, aLog);
    }
    
    public static String process(final String aRules) {
        return process(new String[0], aRules, null, null);
    }
    
    public static String process(final String aRules, final StringBuffer aLog) {
        return process(null, aRules, null, aLog);
    }
    
    public static String process(final String[] aInput, final String aRules) {
        return process(aInput, aRules, null, null);
    }
    
    public static String process(final String[] aInput, final String aRules, final TreeMap<String, String> aVariables) {
        return process(aInput, aRules, aVariables, null);
    }
    
    public static String process(final String[] aInput, final String aRules, final StringBuffer aLog) {
        return process(aInput, aRules, null, aLog);
    }
    
    public static String process(final String[] aInput, String aRules, final TreeMap<String, String> aVariables, final StringBuffer aLog) {
        String ret = "";
        String sKey = "";
        final String sPackage = "com.nirvasoft.rulesengine";
        if (!aRules.equals("")) {
            try {
                aRules = aRules.replace("\n", "");
                final TreeMap<String, Integer> LineIndexes = new TreeMap<String, Integer>();
                TreeMap<String, String> Variables;
                if (aVariables == null) {
                    Variables = new TreeMap<String, String>();
                }
                else {
                    Variables = aVariables;
                }
                final String[] rules = aRules.split(";");
                final String[] lines = new String[rules.length];
                Util.log(aLog, "Input: " + Arrays.toString(aInput) + "\n");
                Util.log(aLog, "Rules: " + aRules + "\n" + "Execution: \n");
                for (int i = 0; i < rules.length; ++i) {
                    if (rules[i].matches(" *(.+): *(.+)")) {
                        sKey = Regex.extract(rules[i], Regex.getLineIndex, 1);
                        lines[i] = sKey;
                        rules[i] = Regex.extract(rules[i], Regex.getLineIndex, 2);
                        LineIndexes.put(sKey, new Integer(i));
                    }
                    else {
                        lines[i] = "";
                    }
                }
                if (aInput != null) {
                    for (int i = 0; i < aInput.length; ++i) {
                        if (aInput[i].matches("([a-zA-Z]+[a-zA-Z0-9]*)[ ]*= *(.+)[ ]*")) {
                            sKey = Regex.extract(aInput[i], Regex.getValueAssignment, 1);
                            final String Value = Regex.extract(aInput[i], Regex.getValueAssignment, 2);
                            Variables.put(sKey, Value);
                        }
                    }
                }
                for (int i = 0; i < rules.length; ++i) {
                    sKey = "";
                    Util.log(aLog, " " + (lines[i].equals("") ? "" : (String.valueOf(lines[i]) + ": ")) + rules[i] + "\n");
                    String sIf = "";
                    String sThen = "";
                    String sElse = "";
                    String rule;
                    if (rules[i].matches("[ ]*[iI][fF] \\((.+)\\) [tT][hH][eE][nN] +([^ ]+) +[eE][lL][sS][eE] *([^ ;]*)[ ;]*")) {
                        sIf = Regex.extract(rules[i], Regex.getIF, 1);
                        sThen = Regex.extract(rules[i], Regex.getIF, 2);
                        sElse = Regex.extract(rules[i], Regex.getIF, 3);
                        if (ifTrue(sIf, Variables, sPackage, aLog)) {
                            rule = sThen;
                        }
                        else {
                            rule = sElse;
                        }
                    }
                    else {
                        rule = rules[i];
                    }
                    if (rule.matches("([a-zA-Z]+[a-zA-Z0-9]*)[ ]*= *(.+)[ ]*")) {
                        sKey = Regex.extract(rule, Regex.getValueAssignment, 1);
                        rule = Regex.extract(rule, Regex.getValueAssignment, 2);
                    }
                    if (rule.toLowerCase().contains("end")) {
                        Util.log(aLog, "   <End>\n");
                        i = rules.length;
                    }
                    else if (rule.toLowerCase().matches("goto\\((.+)\\) *")) {
                        final String sGoto = Regex.extract(rule, Regex.getGoto, 1);
                        Util.log(aLog, "   Goto Line: " + sGoto + "\n");
                        final Integer index = LineIndexes.get(sGoto);
                        i = index - 1;
                    }
                    else {
                        ret = execute(rule, Variables, sKey, sPackage, aLog);
                        Util.log(aLog, "   " + ret + "\n");
                    }
                }
            }
            catch (Exception ex) {
                Util.log(aLog, "*** Exception @ RuleProcessor.processing :" + ex.getMessage() + "\n");
            }
        }
        return ret;
    }
    
    static String execute(String rule, final TreeMap<String, String> Variables, final String sKey, final String sPackage, final StringBuffer aLog) {
        String ret = "";
        if (rule.equalsIgnoreCase("true") || rule.equalsIgnoreCase("false")) {
            ret = rule.toLowerCase();
            if (!sKey.equals("")) {
                Variables.put(sKey, ret);
            }
        }
        else if (rule.matches("[a-zA-Z]+[a-zA-Z0-9]*")) {
            ret = Variables.get(Regex.extract(rule, Regex.getVariableName, 0));
            if (!sKey.equals("")) {
                Variables.put(sKey, ret);
            }
        }
        else if (rule.matches("'(.*)'") || rule.matches("[-+]?[0-9]+\\.?[0-9]*[^%]?")) {
            ret = rule;
            if (!sKey.equals("")) {
                Variables.put(sKey, ret);
            }
        }
        else if (rule.matches("[^ ]+ *([\\+\\-\\*\\/]{1}) *[^ ]+.?")) {
            rule = rule.replace("+", " + ");
            rule = rule.replace("-", " - ");
            rule = rule.replace("*", " * ");
            rule = rule.replace("/", " / ");
            final String[] para = rule.split("[ ]+");
            if (para[0].matches("[a-zA-Z]+[a-zA-Z0-9]*")) {
                para[0] = Variables.get(Regex.extract(para[0], Regex.getVariableName, 0));
            }
            double val = Util.dbl(para[0]);
            for (int l = 2; l < para.length; l += 2) {
                if (para[l].matches("[a-zA-Z]+[a-zA-Z0-9]*")) {
                    para[l] = Variables.get(Regex.extract(para[l], Regex.getVariableName, 0));
                }
                if (para[l - 1].equals("+")) {
                    val += Util.dbl(para[l]);
                }
                else if (para[l - 1].equals("-")) {
                    val -= Util.dbl(para[l]);
                }
                else if (para[l - 1].equals("*")) {
                    val *= Util.dbl(para[l]);
                }
                else if (para[l - 1].equals("/")) {
                    val /= Util.dbl(para[l]);
                }
            }
            ret = Lib.zeroTail(val);
            if (!sKey.equals("")) {
                Variables.put(sKey, ret);
            }
            Util.log(aLog, "   Calculation :  " + ret + "\n");
        }
        else {
            final String FunctionCode = Regex.extract(rule, Regex.getFunctionName, 1);
            Util.log(aLog, "   Function Code: " + FunctionCode + "\n");
            final String[] para2 = para(rule, Variables, aLog);
            ret = reflect(FunctionCode, para2, Variables, sKey, sPackage, aLog);
        }
        return ret;
    }
    
    static String[] para(final String rule, final TreeMap<String, String> Variables, final StringBuffer aLog) {
        final String[] ret = Regex.extract(rule, Regex.getInnerRoundBracket, 1).split(",");
        for (int i = 0; i < ret.length; ++i) {
            if (ret[i].matches("[a-zA-Z]+[a-zA-Z0-9]*")) {
                ret[i] = Variables.get(Regex.extract(ret[i], Regex.getVariableName, 0));
            }
        }
        return ret;
    }
    
    static String reflect(final String aFunctionCode, final String[] aPara, final TreeMap<String, String> aData, final String aKey, final String aPackage, final StringBuffer aLog) {
        final String ret = Util.reflect(aFunctionCode, aPara, aPackage, aLog);
        if (!aKey.equals("")) {
            aData.put(aKey, ret);
        }
        return ret;
    }
    
    static boolean ifTrue(final String sIf, final TreeMap<String, String> Variables, final String pkg, final StringBuffer aLog) {
        boolean ret = false;
        if (sIf.matches(" *(.*?)\\(.*")) {
            final String FunctionCode = Regex.extract(sIf, Regex.getFunctionName, 1);
            Util.log(aLog, "   Function Code: " + FunctionCode + "\n");
            final String[] para = para(sIf, Variables, aLog);
            ret = reflect(FunctionCode, para, Variables, "", pkg, aLog).equalsIgnoreCase("true");
        }
        else {
            ret = condition(sIf, Variables, aLog);
        }
        return ret;
    }
    
    static boolean condition(final String stmt, final TreeMap<String, String> Variables, final StringBuffer aLog) {
        boolean ret = false;
        String a = "";
        String b = "";
        String opt = "=";
        final String[] stmtOR = stmt.split(" +OR +");
        for (int i = 0; i < stmtOR.length; ++i) {
            final String[] stmtAND = stmtOR[i].split(" +AND +");
            boolean bAnd = true;
            for (int j = 0; j < stmtAND.length; ++j) {
                final String S = stmtAND[j];
                if (S.matches("[ ]*([A-Za-z0-9']*) *([><!=]{1,2}) *([A-Za-z0-9']*)[ ]*")) {
                    final String A = Regex.extract(S, Regex.getConStatement, 1);
                    if (A.matches("[a-zA-Z]+[a-zA-Z0-9]*")) {
                        a = Variables.get(A);
                    }
                    else {
                        a = A;
                    }
                    opt = Regex.extract(S, Regex.getConStatement, 2);
                    final String B = Regex.extract(S, Regex.getConStatement, 3);
                    if (!B.equalsIgnoreCase("true") && !B.equalsIgnoreCase("false") && B.matches("[a-zA-Z]+[a-zA-Z0-9]*")) {
                        b = Variables.get(B);
                    }
                    else {
                        b = B;
                    }
                }
                final boolean bcurrent = isTrue(a, opt, b);
                if (stmtAND.length > 1) {
                    Util.log(aLog, "    ");
                }
                Util.log(aLog, "   " + S + " = " + bcurrent + "\n");
                bAnd = (bAnd && bcurrent);
            }
            ret = (ret || bAnd);
            if (stmtAND.length > 1) {
                Util.log(aLog, "   " + stmtOR[i] + " >>> " + bAnd + "\n");
            }
        }
        Util.log(aLog, "   Condition : \"" + stmt + "\" = " + ret + "\n");
        return ret;
    }
    
    static boolean isTrue(final String left, final String opt, final String right) {
        if (left.startsWith("'")) {
            return (opt.equals("==") || opt.equals("=")) && left.equals(right);
        }
        if (right.equalsIgnoreCase("true") || right.equalsIgnoreCase("false")) {
            return (opt.equals("==") || opt.equals("=")) && left.equals(right);
        }
        final double a = Util.dbl(left);
        final double b = Util.dbl(right);
        if (opt.equals("==") || opt.equals("=")) {
            return a == b;
        }
        if (opt.equals("!=")) {
            return a != b;
        }
        if (opt.equals(">=")) {
            return a >= b;
        }
        if (opt.equals("<=")) {
            return a <= b;
        }
        if (opt.equals(">")) {
            return a > b;
        }
        return opt.equals("<") && a < b;
    }
}