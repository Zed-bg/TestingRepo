// 
// Decompiled by Procyon v0.5.36
// 

package com.nirvasoft.rulesengine;

import java.util.ArrayList;

public class Dataset
{
    private ArrayList<String> Data;
    private ArrayList<String> Result;
    
    public ArrayList<String> getData() {
        return this.Data;
    }
    
    public void setData(final ArrayList<String> data) {
        this.Data = data;
    }
    
    public ArrayList<String> getResult() {
        return this.Result;
    }
    
    public void setResult(final ArrayList<String> result) {
        this.Result = result;
    }
}